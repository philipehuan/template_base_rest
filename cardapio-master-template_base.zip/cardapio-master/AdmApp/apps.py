from django.apps import AppConfig


class AdmappConfig(AppConfig):
    name = 'AdmApp'
